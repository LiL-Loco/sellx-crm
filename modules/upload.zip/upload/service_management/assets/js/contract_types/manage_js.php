<script>
    $(function(){
    	"use strict";
    	
        initDataTable('.table-contract-types', window.location.href, [1], [1]);
    });
</script>