<script type="text/javascript">
	    var gallery = new SimpleLightbox('.gallery a', {});
</script>
